# Obie Trice - Cheers
# We do not own or publish the content delivered by the plugin
# streaming online radio

import sys
import xbmcgui
import xbmcplugin
 
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/01 - Obie Trice - Average Man.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Average Man[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/02 - Obie Trice - Cheers.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Cheers[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/03 - Obie Trice - Got Some Teeth.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Got Some Teeth[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/04 - Obie Trice - Lady (feat. Eminem).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Lady[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/05 - Obie Trice - Do.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Dont Come Down[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/06 - Obie Trice - The Set Up (feat. Nate Dogg).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]The Setup[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/07 - Obie Trice - Bad Bitch.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Bad Bitch[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/08 - Obie Trice - Shit Hits The Fan (feat. Dr. Dre).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Shit Hits The Fan[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/09 - Obie Trice - Follow My Life.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Follow My Life[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/10 - Obie Trice - We All Die One Day (feat. 50 Cent, Lloyd Banks Of G-Unit And Eminem).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]We All Die One Day[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/11 - Obie Trice - Spread Yo Shit (feat. Kon Artis Of D12).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Spread Yo Shit[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/12 - Obie Trice - Look In My Eyes (feat. Nate Dogg).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Look In My Eyes[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/13 - Obie Trice - Hands On You (feat. Eminem).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Hands On You[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/14 - Obie Trice - Hoodrats.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Hoodrats[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/15 - Obie Trice - Oh! (feat. Busta Rhymes).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Oh![/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/16 - Obie Trice - Never Forget Ya.mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Never Forget Ya[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://archive.org/download/10ObieTriceWeAllDieOneDayfeat.50CentLloydBanksOfGUnitAndEminem/Obie Trice - Cheers - (NUXX)/17 - Obie Trice - Outro (feat. D12).mp3'
li = xbmcgui.ListItem('[COLOR limegreen]Outro[/COLOR]', iconImage='https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0', thumbnailImage= 'https://dl.dropboxusercontent.com/s/clud5pn5ht6kmdn/icon%20%282%29.png?dl=0')
li.setProperty('fanart_image', 'https://dl.dropboxusercontent.com/s/g63hoagqvzwsgxf/trice-obie-54905d1dcd380.jpg?dl=0')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)

